package com.example.contact;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.example.contact.Utils.UniversalImageLoader;
import com.example.contact.models.Contact;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

public class MainActivity extends AppCompatActivity implements ViewContactsFragment.OnContactSelectedListener {

        private static final String TAG = "MainActivity";

        @Override
        public void OnContactSelected(Contact contact) {
            Log.d(TAG, "OnContactSelected: contact selected from "
                    + getString(R.string.view_contacts_fragment)
                    + " " + contact.getName());

            ContactFragment fragment = new ContactFragment();
            Bundle args = new Bundle();
            args.putParcelable(getString(R.string.contact), contact);
            fragment.setArguments(args);

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, fragment);
            transaction.addToBackStack(getString(R.string.contact_fragment));
            transaction.commit();
        }


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Log.d(TAG, "onCreate: started.");
            initImageLoader();
            init();
        }

        /**
         * initialize the first fragment (ViewContactsFragment)
         */
        private void init() {
            ViewContactsFragment fragment = new ViewContactsFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            // reaplce whatever is in the fragment_container view with this fragment,
            // amd add the transaction to the back stack so the user can navigate back
            transaction.replace(R.id.fragment_container, fragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }

        private void initImageLoader() {
            UniversalImageLoader universalImageLoader = new UniversalImageLoader(MainActivity.this);
            ImageLoader.getInstance().init(universalImageLoader.getConfig());
        }

    }
