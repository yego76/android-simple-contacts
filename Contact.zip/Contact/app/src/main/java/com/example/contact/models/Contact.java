package com.example.contact.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Contact implements Parcelable {
    private String name;
    private String phonenumber;
    private String email;
    private String device;
    private String profileimage; //i think it should be from the files/documents images etc

    public Contact(String name,String phonenumber,String email ,String device ,String profileimage){
        this.name =name;
        this.phonenumber =phonenumber;
        this.email =email;
        this.device =device;
        this.profileimage =profileimage;
    }

    protected Contact(Parcel in) {
        name = in.readString();
        phonenumber = in.readString();
        email = in.readString();
        device = in.readString();
        profileimage = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(phonenumber);
        dest.writeString(email);
        dest.writeString(device);
        dest.writeString(profileimage);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override
        public Contact createFromParcel(Parcel in) {
            return new Contact(in);
        }

        @Override
        public Contact[] newArray(int size) {
            return new Contact[size];
        }
    };

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }
    public String toString(){
        return "Contact{" +
                "name='" +name +'/'+
                ",phonenumber="+phonenumber +'/'+
                ",email="+email +'/' +
                ",device="+ device +'/'+
                ",profileimage" +'/'+
                '}';
    }
}
